#----------------------
# (1) loading packages 
#----------------------



#---------------------
# (2) reading in data 
#---------------------
# specifying symbols that will be in the analysis




# getting the data from Yahoo finance




#-------------------
# (3) data checking 
#-------------------
# checking number of symbols is correct




# checking date range




#-------------------------------
# (4) add columns to group with 
#-------------------------------
# adding year and date columns



# there should be 120 rows = 10 etfs * 12 months





#-----------------------------------------
# (5) generate monthly performance report 
#-----------------------------------------





#-----------------------------------------------
# (6) print monthly report to data_output folder
#-----------------------------------------------







