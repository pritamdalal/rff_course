#--------------------------------------------
# (1) You can type directly into the console.
#--------------------------------------------
##> exp(0.01) - 1


#----------------------------------------------------------
# (2) You can also assign variables directly in the console
#----------------------------------------------------------
##> etfs <- c("SPY", "IWM")


#------------------------------------------------------------------
# (3) Notice the variable etfs shows up in your environment window.
# (4) I don't type directly into the console very much.
# (5) Rather, I type into an .R file and then run selected code.
# (6) This is how we will proceed for the rest of this tutorial.
#------------------------------------------------------------------


#-----------------------------------------------------------
# (7) Press: CTRL + SHIFT + F10.
# (8) This restarts your R session, which deletes variables
#     and unloads all pacakges.
#-----------------------------------------------------------


#----------------------------------------------------------
# (9) Press CTRL + L to clear the text from your console
# (10) This clears all the text from your console
#----------------------------------------------------------


#--------------------------------------------------------
# (11) Type the following in this script and then press: 
#      CTRL + ENTER.
#--------------------------------------------------------
##> exp(0.01) - 1
exp(0.01) - 1



#--------------------------------------------------------
# (12) You can do variable assignment in this script too.
#--------------------------------------------------------
##> etfs <- c("SPY", "IWM")
etfs <- c("SPY", "IWM")


#---------------------------------------------------
# (13) Check your environment for the variable etfs.
#---------------------------------------------------


#------------------------------------------------------
# (14) Let's look at the contents of the variable etfs. 
#------------------------------------------------------
##> etfs
etfs


#-----------------------------------------
# (15) We can load packages from a script.
#-----------------------------------------
library(tidyverse)
library(tidyquant)


#-----------------------------------------------
# (16) Let's query some data from yahoo finance 
#-----------------------------------------------
symbols <- c("SPY", "IWM", "QQQ", "DIA")
df_etf <- tq_get(symbols, get = "stock.prices"
                 , from = "2018-12-01", to = "2019-01-01")


#------------------------------------
# (17) let's take a look at our data 
#------------------------------------
##> df_etf
df_etf


#-----------------------------------------------------------------
# (18) As you can see, the workflow in a .R script is very similar 
#      the workfowm to the .Rmd Rmarkdown document
# (19) However, there are no code chunks.
# (20) And ouput is printed to the console, rather than
#      below the code.
#------------------------------------------------------------------
    

#---------------------------------------------------------------------
# (21) to get some practice executing code in scripts let's calculated
#      the monthly-return and monthly-volatility for the four ETFs in
#      our data set.
#---------------------------------------------------------------------


#-------------------------------------------------------------------
# (22) Recall that this is going to entail a few tidyverse steps:
#      i.   select the symbol, date, close columns
#      ii.  group_by() symbol
#      iii. use mutate() to calculate daily returns
#      iv.  use summrize() to calculate monthly statistics 
#           from daily returns
#--------------------------------------------------------------------
##> df_etf %>% 
##>     select(symbol, date, close) %>% 
##>     group_by(symbol) %>% 
##>     mutate(
##>         daily_ret = (close / lag(close)) - 1
##>     ) %>% 
##>     summarize(
##>         monthly_ret = prod(1 + daily_ret, na.rm = TRUE) - 1
##>         , monthly_vol = sd(daily_ret, na.rm = TRUE) * sqrt(252)
##>     )
df_etf %>% 
    select(symbol, date, close) %>% 
    group_by(symbol) %>% 
    mutate(
        daily_ret = (close / lag(close)) - 1
    ) %>% 
    summarize(
        monthly_ret = prod(1 + daily_ret, na.rm = TRUE) - 1
        , monthly_vol = sd(daily_ret, na.rm = TRUE) * sqrt(252)
    )


#---------------------------------------------------------------------
# (23) Restart R by pressing: CRTL + SHIFT + F10
# (24) Check your environment to make sure it is emty.
# (25) Clear the console by pressing: CRTL + L
# (26) We can run the entire script by pressing: CTRL + SHIFT + ENTER
#---------------------------------------------------------------------











