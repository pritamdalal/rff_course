#----------------------
# (1) loading packages 
#----------------------
library(tidyverse)
library(tidyquant)
library(lubridate)



#---------------------
# (2) reading in data 
#---------------------
# specifying symbols that will be in the analysis
symbols <- 
    c("XLY", "XLP", "XLE", "XLF", "XLV" 
      , "XLI", "XLB", "XLRE", "XLK", "XLU")

# getting the data from Yahoo finance
df_etf <- 
    tq_get(
        symbols, get = "stock.prices"
        , from = "2018-01-01", to = "2019-01-01"
    )



#-------------------
# (3) data checking 
#-------------------
# checking number of symbols is correct
length(symbols) ==
    df_etf %>% distinct(symbol) %>% nrow()

# checking date range
df_etf %>% 
    summarize(
        min_date = min(date)
        , max_date = max(date)
    )



#-------------------------------
# (4) add year and month columns
#-------------------------------
# adding year and date columns
df_etf <- 
    df_etf %>% 
        mutate(
            year = year(date)
            , month = month(date)
        )

# there should be 120 rows = 10 etfs * 12 months
df_etf %>% distinct(symbol, year, month)



#-----------------------------------------
# (5) generate monthly performance report 
#-----------------------------------------
df_report <- 
    df_etf %>% 
        select(symbol, year, month, date, close) %>% 
        group_by(symbol, year, month) %>% 
        mutate(
            daily_ret = (close / lag(close)) - 1
        ) %>% 
        summarize(
            monthly_ret = prod(1 + daily_ret, na.rm = TRUE) - 1
            , monthly_vol = sd(daily_ret, na.rm = TRUE) * sqrt(252)
        )


#-----------------------------------------------
# (6) print monthly report to data_output folder
#-----------------------------------------------
write_csv(df_report, "02_data_output/monthly_report_solution.csv")







